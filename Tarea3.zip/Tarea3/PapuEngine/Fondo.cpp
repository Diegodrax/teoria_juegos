#include "Fondo.h"
#include "ResourceManager.h"
#include "GLTexture.h"

Fondo::Fondo()
{
}

Fondo::~Fondo()
{
}

void Fondo::draw(SpriteBacth& spriteBatch)
{
	Color color;
	color.r = 255;
	color.g = 255;
	color.b = 255;
	color.a = 255;
	glm::vec4 uv(0.0f, 0.0f, 1.0f, 1.0f);
	static GLTexture texture = ResourceManager::getTexture("Textures/space_final.png");
	glm::vec4 posAnSize = glm::vec4(0, 0, 3072, 2048);
	spriteBatch.draw(posAnSize, uv, texture.id, 0.0f, color);
}