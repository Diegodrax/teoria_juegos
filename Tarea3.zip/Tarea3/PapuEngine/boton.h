#pragma once
#include <glm/glm.hpp>
#include "SpriteBacth.h"

class boton
{
private:
	glm::vec2 _position;
public:
	boton(glm::vec2 po);
	~boton();
	void draw(SpriteBacth& spriteBatch);
	void update();
};