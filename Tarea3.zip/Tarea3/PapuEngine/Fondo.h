#pragma once
#include <glm/glm.hpp>
#include "SpriteBacth.h"

class Fondo
{
public:
	Fondo();
	~Fondo();
	void draw(SpriteBacth& spriteBatch);
};