#pragma once

namespace Papu {
	extern int init();
}

