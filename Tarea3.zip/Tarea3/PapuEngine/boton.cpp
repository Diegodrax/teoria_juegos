#include "boton.h"
#include "ResourceManager.h"
#include "GLTexture.h"

boton::boton(glm::vec2 po)
{
	_position = po;
}

boton::~boton(){}

void boton::draw(SpriteBacth& spriteBatch)
{
	Color color;
	color.r = 255;
	color.g = 255;
	color.b = 255;
	color.a = 255;
	glm::vec4 uv(0.0f, 0.0f, 1.0f, 1.0f);
	static GLTexture texture = ResourceManager::getTexture("Textures/boton_base.png");
	glm::vec4 posAnSize = glm::vec4(_position.x, _position.y, 30, 30);
	spriteBatch.draw(posAnSize, uv, texture.id, 0.0f, color);
}

void boton::update()
{
}